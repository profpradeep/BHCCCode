#!/usr/bin/env bash
# Installs Hatch prerequisites on macOS, Debian/Ubuntu, Fedora, or Arch Linux.
# Node.js and the Hatch CLI remain private to this signed-in user. VS Code and
# VS Code uses its platform-supported installer, which may require sudo.
set -euo pipefail

repository_root="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
hatch_home="${HATCH_HOME:-$HOME/.hatch}"
node_home="$hatch_home/runtime/node"
node_bin="$node_home/bin"
app_home="$hatch_home/app"
npm_prefix="$hatch_home/npm"
product_name='Hatch Code'
command_name='hatch-code'
icon_relative_path=''

command_exists() { command -v "$1" >/dev/null 2>&1; }
git_exists() { command_exists git && git --version >/dev/null 2>&1; }
need_sudo() { if ! command_exists sudo; then echo "sudo is required to install system packages." >&2; exit 1; fi; sudo -v; }

node_platform() {
  case "$(uname -s):$(uname -m)" in
    Darwin:arm64) printf 'darwin-arm64' ;;
    Darwin:x86_64) printf 'darwin-x64' ;;
    Linux:x86_64) printf 'linux-x64' ;;
    Linux:aarch64|Linux:arm64) printf 'linux-arm64' ;;
    *) echo "Unsupported Node.js platform: $(uname -s) $(uname -m)" >&2; exit 1 ;;
  esac
}

sha256() {
  if command_exists sha256sum; then sha256sum "$1" | awk '{print $1}'
  else shasum -a 256 "$1" | awk '{print $1}'
  fi
}

install_user_node() {
  if [ -x "$node_home/bin/node" ]; then return; fi
  local existing_node existing_bin existing_version
  existing_node="$(type -P node || true)"
  if [ -n "$existing_node" ]; then
    existing_bin="$(cd -- "$(dirname -- "$existing_node")" && pwd)"
    existing_version="$("$existing_node" --version 2>/dev/null || true)"
    if [[ "$existing_version" =~ ^v24\.[0-9]+\.[0-9]+$ ]] && [ -x "$existing_bin/npm" ] && PATH="$existing_bin:$PATH" "$existing_bin/npm" --version >/dev/null 2>&1; then
      node_bin="$existing_bin"
      echo "Using existing Node.js $existing_version at $node_bin"
      return
    fi
  fi
  ensure_curl
  local platform manifest archive_name expected_hash version temporary archive extracted actual_hash
  platform="$(node_platform)"
  manifest="$(curl --fail --silent --show-error --location 'https://nodejs.org/dist/latest-v24.x/SHASUMS256.txt')"
  archive_name="$(printf '%s\n' "$manifest" | awk -v suffix="-$platform.tar.gz" '$2 ~ suffix"$" { print $2; exit }')"
  expected_hash="$(printf '%s\n' "$manifest" | awk -v file="$archive_name" '$2 == file { print tolower($1); exit }')"
  if [ -z "$archive_name" ] || [ -z "$expected_hash" ]; then echo "Could not find a Node.js 24 LTS archive for $platform." >&2; exit 1; fi
  version="${archive_name#node-}"; version="${version%-${platform}.tar.gz}"
  temporary="$(mktemp -d "${TMPDIR:-/tmp}/hatch-node.XXXXXX")"
  archive="$temporary/$archive_name"
  trap 'rm -rf "$temporary"' RETURN
  echo "Installing private Node.js LTS for this user..."
  curl --fail --silent --show-error --location "https://nodejs.org/dist/$version/$archive_name" --output "$archive"
  actual_hash="$(sha256 "$archive")"
  if [ "$actual_hash" != "$expected_hash" ]; then echo 'The downloaded Node.js archive did not match its published checksum.' >&2; exit 1; fi
  tar -xzf "$archive" -C "$temporary"
  extracted="$temporary/node-$version-$platform"
  if [ ! -x "$extracted/bin/node" ]; then echo 'The Node.js archive did not contain the expected runtime.' >&2; exit 1; fi
  mkdir -p "$(dirname "$node_home")"
  mv "$extracted" "$node_home"
  trap - RETURN
  rm -rf "$temporary"
}

install_macos() {
  if ! command_exists brew; then
    echo 'Homebrew is required to install Git and VS Code. Install it from https://brew.sh, then rerun this script.' >&2
    exit 1
  fi
  git_exists || brew install git
  command_exists code || brew install --cask visual-studio-code
}

install_debian() {
  need_sudo
  sudo apt-get update
  sudo apt-get install -y ca-certificates curl gpg
  git_exists || sudo apt-get install -y git
  if ! command_exists code; then
    curl -fsSL https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor | sudo tee /usr/share/keyrings/packages.microsoft.gpg >/dev/null
    echo 'deb [arch=amd64,arm64,armhf signed-by=/usr/share/keyrings/packages.microsoft.gpg] https://packages.microsoft.com/repos/code stable main' | sudo tee /etc/apt/sources.list.d/vscode.list >/dev/null
    sudo apt-get update
    sudo apt-get install -y code
  fi
}

install_fedora() {
  need_sudo
  git_exists || sudo dnf install -y git
  if ! command_exists code; then
    sudo rpm --import https://packages.microsoft.com/keys/microsoft.asc
    sudo sh -c 'printf "[code]\\nname=Visual Studio Code\\nbaseurl=https://packages.microsoft.com/yumrepos/vscode\\nenabled=1\\nautorefresh=1\\ngpgcheck=1\\ngpgkey=https://packages.microsoft.com/keys/microsoft.asc\\n" > /etc/yum.repos.d/vscode.repo'
    sudo dnf check-update || true
    sudo dnf install -y code
  fi
}

install_arch() {
  need_sudo
  git_exists || sudo pacman -S --noconfirm git
  command_exists code || sudo pacman -S --noconfirm code
}

install_hatch_application() {
  local temporary_app="$hatch_home/app-installing"
  if [ ! -d "$repository_root/cli" ] || [ ! -d "$repository_root/vscode-profile" ]; then
    echo 'The extracted installer is incomplete: cli and vscode-profile are required.' >&2
    exit 1
  fi
  rm -rf "$temporary_app"
  mkdir -p "$temporary_app"
  cp -R "$repository_root/cli" "$temporary_app/cli"
  cp -R "$repository_root/vscode-profile" "$temporary_app/vscode-profile"
  rm -rf "$app_home"
  mv "$temporary_app" "$app_home"
}

create_desktop_shortcut() {
  local desktop shortcut launcher custom_icon app executable
  launcher="$hatch_home/launch-hatch-code.sh"
  mkdir -p "$hatch_home"
  printf '#!/usr/bin/env bash\nexport PATH=%q:$PATH\nexec %q "$@"\n' "$node_bin" "$npm_prefix/bin/$command_name" > "$launcher"
  chmod +x "$launcher"
  if [ "$(uname -s)" = Darwin ]; then
    desktop="$(osascript -e 'POSIX path of (path to desktop folder)' 2>/dev/null || printf '%s/Desktop/' "$HOME")"
    mkdir -p "${desktop%/}"
    if [ -n "$icon_relative_path" ]; then
      app="${desktop%/}/$product_name.app"
      executable="$app/Contents/MacOS/launcher"
      custom_icon="$app_home/cli/$icon_relative_path"
      rm -rf "$app"
      mkdir -p "$app/Contents/MacOS" "$app/Contents/Resources"
      cp "$custom_icon" "$app/Contents/Resources/icon.icns"
      printf '#!/usr/bin/env bash\nexec %q "$@"\n' "$launcher" > "$executable"
      chmod +x "$executable"
      cat > "$app/Contents/Info.plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleExecutable</key><string>launcher</string>
<key>CFBundleIconFile</key><string>icon</string>
<key>CFBundleIdentifier</key><string>edu.hatch.branded-launcher</string>
<key>CFBundlePackageType</key><string>APPL</string>
</dict></plist>
EOF
    else
      shortcut="${desktop%/}/$product_name.command"
      printf '#!/usr/bin/env bash\nexec %q "$@"\n' "$launcher" > "$shortcut"
      chmod +x "$shortcut"
    fi
  else
    desktop="$(xdg-user-dir DESKTOP 2>/dev/null || printf '%s/Desktop' "$HOME")"
    shortcut="$desktop/$product_name.desktop"
    mkdir -p "$desktop"
    {
      printf '[Desktop Entry]\nType=Application\nVersion=1.0\nName=%s\nComment=Open the isolated %s development environment\nExec=%s\n' "$product_name" "$product_name" "${launcher// /\\ }"
      if [ -n "$icon_relative_path" ]; then printf 'Icon=%s\n' "$app_home/cli/$icon_relative_path"; fi
      printf 'Terminal=false\nCategories=Development;Education;\n'
    } > "$shortcut"
    chmod +x "$shortcut"
  fi
}

ensure_curl() {
if ! command_exists curl; then
  case "$(uname -s)" in
    Linux)
      need_sudo
      if command_exists apt-get; then sudo apt-get update; sudo apt-get install -y curl
      elif command_exists dnf; then sudo dnf install -y curl
      elif command_exists pacman; then sudo pacman -Sy --noconfirm curl
      else echo 'curl is required to download the private Node.js runtime.' >&2; exit 1
      fi ;;
    *) echo 'curl is required to download the private Node.js runtime.' >&2; exit 1 ;;
  esac
fi
}
install_user_node
product_name="$("$node_bin/node" -p "require(process.argv[1]).productName" "$repository_root/cli/branding.json")"
command_name="$("$node_bin/node" -p "require(process.argv[1]).commandName" "$repository_root/cli/branding.json")"
icon_relative_path="$("$node_bin/node" -p "require(process.argv[1]).iconPath || ''" "$repository_root/cli/branding.json")"
export PATH="$node_bin:$npm_prefix/bin:$PATH"

case "$(uname -s)" in
  Darwin) install_macos ;;
  Linux)
    if command_exists apt-get; then install_debian
    elif command_exists dnf; then install_fedora
    elif command_exists pacman; then install_arch
    else echo 'Unsupported Linux package manager. Install VS Code, then rerun this script.' >&2; exit 1
    fi ;;
  *) echo "Unsupported operating system: $(uname -s)" >&2; exit 1 ;;
esac

install_hatch_application
cd "$app_home"
"$node_bin/npm" install --global --prefix "$npm_prefix" ./cli
"$npm_prefix/bin/$command_name" configure-languages
create_desktop_shortcut

echo "$product_name is configured. Open any folder from the desktop shortcut or $command_name command."
