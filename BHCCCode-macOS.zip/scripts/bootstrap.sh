#!/usr/bin/env bash
# Installs Hatch prerequisites on macOS, Debian/Ubuntu, Fedora, or Arch Linux.
# Node.js and the Hatch CLI remain private to this signed-in user. VS Code and
# VS Code uses its platform-supported installer, which may require sudo.
set -euo pipefail

repository_root="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
hatch_home="${HATCH_HOME:-$HOME/.hatch}"
node_home="$hatch_home/runtime/node"
node_bin="$node_home/bin"
app_home="$hatch_home/app"
npm_prefix="$hatch_home/npm"
product_name='Hatch Code'
command_name='hatch-code'
icon_relative_path=''

command_exists() { command -v "$1" >/dev/null 2>&1; }
git_exists() { command_exists git && git --version >/dev/null 2>&1; }
need_sudo() { if ! command_exists sudo; then echo "sudo is required to install system packages." >&2; exit 1; fi; sudo -v; }

node_platform() {
  case "$(uname -s):$(uname -m)" in
    Darwin:arm64) printf 'darwin-arm64' ;;
    Darwin:x86_64) printf 'darwin-x64' ;;
    Linux:x86_64) printf 'linux-x64' ;;
    Linux:aarch64|Linux:arm64) printf 'linux-arm64' ;;
    *) echo "Unsupported Node.js platform: $(uname -s) $(uname -m)" >&2; exit 1 ;;
  esac
}

sha256() {
  if command_exists sha256sum; then sha256sum "$1" | awk '{print $1}'
  else shasum -a 256 "$1" | awk '{print $1}'
  fi
}

install_user_node() {
  if [ -x "$node_home/bin/node" ]; then return; fi
  local existing_node existing_bin existing_version
  existing_node="$(type -P node || true)"
  if [ -n "$existing_node" ]; then
    existing_bin="$(cd -- "$(dirname -- "$existing_node")" && pwd)"
    existing_version="$("$existing_node" --version 2>/dev/null || true)"
    if [[ "$existing_version" =~ ^v([0-9]+)\.[0-9]+\.[0-9]+$ ]] && (( 10#${BASH_REMATCH[1]} >= 18 )) && [ -x "$existing_bin/npm" ] && PATH="$existing_bin:$PATH" "$existing_bin/npm" --version >/dev/null 2>&1; then
      node_bin="$existing_bin"
      echo "Using existing Node.js $existing_version at $node_bin"
      return
    fi
  fi
  ensure_curl
  local platform manifest archive_name expected_hash version temporary archive extracted actual_hash
  platform="$(node_platform)"
  manifest="$(curl --fail --silent --show-error --location 'https://nodejs.org/dist/latest-v24.x/SHASUMS256.txt')"
  archive_name="$(printf '%s\n' "$manifest" | awk -v suffix="-$platform.tar.gz" '$2 ~ suffix"$" { print $2; exit }')"
  expected_hash="$(printf '%s\n' "$manifest" | awk -v file="$archive_name" '$2 == file { print tolower($1); exit }')"
  if [ -z "$archive_name" ] || [ -z "$expected_hash" ]; then echo "Could not find a Node.js 24 LTS archive for $platform." >&2; exit 1; fi
  version="${archive_name#node-}"; version="${version%-${platform}.tar.gz}"
  temporary="$(mktemp -d "${TMPDIR:-/tmp}/hatch-node.XXXXXX")"
  archive="$temporary/$archive_name"
  trap 'rm -rf "$temporary"' RETURN
  echo "Installing private Node.js LTS for this user..."
  curl --fail --silent --show-error --location "https://nodejs.org/dist/$version/$archive_name" --output "$archive"
  actual_hash="$(sha256 "$archive")"
  if [ "$actual_hash" != "$expected_hash" ]; then echo 'The downloaded Node.js archive did not match its published checksum.' >&2; exit 1; fi
  tar -xzf "$archive" -C "$temporary"
  extracted="$temporary/node-$version-$platform"
  if [ ! -x "$extracted/bin/node" ]; then echo 'The Node.js archive did not contain the expected runtime.' >&2; exit 1; fi
  mkdir -p "$(dirname "$node_home")"
  mv "$extracted" "$node_home"
  trap - RETURN
  rm -rf "$temporary"
}

activate_macos_homebrew() {
  local candidate
  if command_exists brew; then return 0; fi
  for candidate in /opt/homebrew/bin/brew /usr/local/bin/brew; do
    if [ -x "$candidate" ]; then
      local environment
      environment="$("$candidate" shellenv bash)" || return 1
      eval "$environment"
      command_exists brew && return 0
    fi
  done
  return 1
}

ensure_macos_homebrew() {
  if activate_macos_homebrew; then return; fi
  echo 'Installing Homebrew to install missing Git or VS Code. Homebrew may ask for confirmation and your administrator password.'
  local installer
  if ! installer="$(curl --fail --silent --show-error --location 'https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh')"; then
    echo 'Could not download the Homebrew installer. Check your connection and rerun setup.' >&2
    return 1
  fi
  if ! /bin/bash -c "$installer"; then
    echo 'Homebrew installation failed. Resolve the error above and rerun setup.' >&2
    return 1
  fi
  if ! activate_macos_homebrew; then
    echo 'Homebrew was not found after installation. Follow the instructions at https://brew.sh and rerun setup.' >&2
    return 1
  fi
}

install_macos() {
  local candidate
  if [ -z "${HATCH_CODE_BIN:-}" ]; then
    for candidate in "$HOME/Applications/Visual Studio Code.app/Contents/Resources/app/bin/code" '/Applications/Visual Studio Code.app/Contents/Resources/app/bin/code'; do
      if [ -x "$candidate" ]; then
        export HATCH_CODE_BIN="$candidate"
        break
      fi
    done
  fi
  if git_exists && { [ -n "${HATCH_CODE_BIN:-}" ] || command_exists code; }; then
    return
  fi
  ensure_macos_homebrew || return 1
  git_exists || brew install git
  if [ -z "${HATCH_CODE_BIN:-}" ] && ! command_exists code; then
    brew install --cask visual-studio-code
  fi
}

install_debian() {
  need_sudo
  sudo apt-get update
  sudo apt-get install -y ca-certificates curl gpg
  git_exists || sudo apt-get install -y git
  if ! command_exists code; then
    curl -fsSL https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor | sudo tee /usr/share/keyrings/packages.microsoft.gpg >/dev/null
    echo 'deb [arch=amd64,arm64,armhf signed-by=/usr/share/keyrings/packages.microsoft.gpg] https://packages.microsoft.com/repos/code stable main' | sudo tee /etc/apt/sources.list.d/vscode.list >/dev/null
    sudo apt-get update
    sudo apt-get install -y code
  fi
}

install_fedora() {
  need_sudo
  git_exists || sudo dnf install -y git
  if ! command_exists code; then
    sudo rpm --import https://packages.microsoft.com/keys/microsoft.asc
    sudo sh -c 'printf "[code]\\nname=Visual Studio Code\\nbaseurl=https://packages.microsoft.com/yumrepos/vscode\\nenabled=1\\nautorefresh=1\\ngpgcheck=1\\ngpgkey=https://packages.microsoft.com/keys/microsoft.asc\\n" > /etc/yum.repos.d/vscode.repo'
    sudo dnf check-update || true
    sudo dnf install -y code
  fi
}

install_arch() {
  need_sudo
  git_exists || sudo pacman -S --noconfirm git
  command_exists code || sudo pacman -S --noconfirm code
}

install_hatch_application() {
  local temporary_app="$hatch_home/app-installing"
  if [ ! -d "$repository_root/cli" ] || [ ! -d "$repository_root/vscode-profile" ]; then
    echo 'The extracted installer is incomplete: cli and vscode-profile are required.' >&2
    exit 1
  fi
  rm -rf "$temporary_app"
  mkdir -p "$temporary_app"
  cp -R "$repository_root/cli" "$temporary_app/cli"
  cp -R "$repository_root/vscode-profile" "$temporary_app/vscode-profile"
  rm -rf "$app_home"
  mv "$temporary_app" "$app_home"
}

create_desktop_shortcut() {
  local desktop shortcut launcher custom_icon app executable display_name icon_entry code_bin desktop_exec
  launcher="$hatch_home/launch-hatch-code.sh"
  mkdir -p "$hatch_home"
  code_bin="${HATCH_CODE_BIN:-$(type -P code || true)}"
  if [ -n "$code_bin" ] && [ -f "$code_bin" ]; then
    code_bin="$(cd -- "$(dirname -- "$code_bin")" && pwd)/$(basename -- "$code_bin")"
  fi
  {
    printf '#!/usr/bin/env bash\nexport PATH=%q:$PATH\n' "$node_bin"
    if [ -n "$code_bin" ]; then
      printf 'if [ -z "${HATCH_CODE_BIN:-}" ]; then export HATCH_CODE_BIN=%q; fi\n' "$code_bin"
    fi
    printf 'exec %q "$@"\n' "$npm_prefix/bin/$command_name"
  } > "$launcher"
  chmod +x "$launcher"
  # Expose only the Hatch command, keeping the selected Node runtime private.
  mkdir -p "$hatch_home/bin"
  printf '#!/usr/bin/env bash\nexec %q "$@"\n' "$launcher" > "$hatch_home/bin/$command_name"
  chmod +x "$hatch_home/bin/$command_name"
  if [ "$(uname -s)" = Darwin ]; then
    desktop="$(osascript -e 'POSIX path of (path to desktop folder)' 2>/dev/null || printf '%s/Desktop/' "$HOME")"
    mkdir -p "${desktop%/}"
    # Finder launches app bundles directly, without opening Terminal.
      app="${desktop%/}/$product_name.app"
      executable="$app/Contents/MacOS/launcher"
      rm -rf "$app"
      mkdir -p "$app/Contents/MacOS" "$app/Contents/Resources"
      custom_icon=''
      if [ -n "$icon_relative_path" ]; then
        custom_icon="$app_home/cli/$icon_relative_path"
      elif [ -f '/Applications/Visual Studio Code.app/Contents/Resources/Code.icns' ]; then
        custom_icon='/Applications/Visual Studio Code.app/Contents/Resources/Code.icns'
      elif [ -f "$HOME/Applications/Visual Studio Code.app/Contents/Resources/Code.icns" ]; then
        custom_icon="$HOME/Applications/Visual Studio Code.app/Contents/Resources/Code.icns"
      fi
      icon_entry=''
      if [ -n "$custom_icon" ]; then
        cp "$custom_icon" "$app/Contents/Resources/icon.icns"
        icon_entry='<key>CFBundleIconFile</key><string>icon</string>'
      fi
      display_name="$("$node_bin/node" -e 'process.stdout.write(process.argv[1].replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"))' "$product_name")"
      printf '#!/usr/bin/env bash\nexec %q "$@"\n' "$launcher" > "$executable"
      chmod +x "$executable"
      cat > "$app/Contents/Info.plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleExecutable</key><string>launcher</string>
${icon_entry}
<key>CFBundleName</key><string>${display_name}</string>
<key>CFBundleDisplayName</key><string>${display_name}</string>
<key>LSUIElement</key><true/>
<key>CFBundleIdentifier</key><string>edu.hatch.branded-launcher</string>
<key>CFBundlePackageType</key><string>APPL</string>
</dict></plist>
EOF
      # Migrate only the legacy shortcut generated by Hatch.
      shortcut="${desktop%/}/$product_name.command"
      if [ -f "$shortcut" ] && cmp -s "$shortcut" <(printf '#!/usr/bin/env bash\nexec %q "$@"\n' "$launcher"); then
        rm "$shortcut"
      fi
  else
    desktop="$(xdg-user-dir DESKTOP 2>/dev/null || printf '%s/Desktop' "$HOME")"
    shortcut="$desktop/$product_name.desktop"
    mkdir -p "$desktop"
    # Desktop Entry escaping is distinct from shell escaping.
    desktop_exec="$("$node_bin/node" -e 'const q = String.fromCharCode(34); process.stdout.write(q + process.argv[1].replace(/[\\"`$]/g, c => "\\" + c).replace(/\\/g, "\\\\").replace(/%/g, "%%") + q)' "$launcher")"
    {
      printf '[Desktop Entry]\nType=Application\nVersion=1.0\nName=%s\nComment=Open the isolated %s development environment\nExec=%s\n' "$product_name" "$product_name" "$desktop_exec"
      if [ -n "$icon_relative_path" ]; then printf 'Icon=%s\n' "$app_home/cli/$icon_relative_path"; fi
      printf 'Terminal=false\nCategories=Development;Education;\n'
    } > "$shortcut"
    chmod +x "$shortcut"
  fi
}

ensure_curl() {
if ! command_exists curl; then
  case "$(uname -s)" in
    Linux)
      need_sudo
      if command_exists apt-get; then sudo apt-get update; sudo apt-get install -y curl
      elif command_exists dnf; then sudo dnf install -y curl
      elif command_exists pacman; then sudo pacman -Sy --noconfirm curl
      else echo 'curl is required to download the private Node.js runtime.' >&2; exit 1
      fi ;;
    *) echo 'curl is required to download the private Node.js runtime.' >&2; exit 1 ;;
  esac
fi
}
install_user_node
product_name="$("$node_bin/node" -p "require(process.argv[1]).productName" "$repository_root/cli/branding.json")"
command_name="$("$node_bin/node" -p "require(process.argv[1]).commandName" "$repository_root/cli/branding.json")"
icon_relative_path="$("$node_bin/node" -p "require(process.argv[1]).iconPath || ''" "$repository_root/cli/branding.json")"
export PATH="$node_bin:$npm_prefix/bin:$PATH"

case "$(uname -s)" in
  Darwin) install_macos ;;
  Linux)
    if command_exists apt-get; then install_debian
    elif command_exists dnf; then install_fedora
    elif command_exists pacman; then install_arch
    else echo 'Unsupported Linux package manager. Install VS Code, then rerun this script.' >&2; exit 1
    fi ;;
  *) echo "Unsupported operating system: $(uname -s)" >&2; exit 1 ;;
esac

install_hatch_application
cd "$app_home"
"$node_bin/npm" install --global --prefix "$npm_prefix" ./cli
"$npm_prefix/bin/$command_name" configure-languages
create_desktop_shortcut
"$node_bin/node" "$app_home/cli/lib/shell-path.js" "$hatch_home"

echo "$product_name is configured. Open the desktop shortcut, or use $command_name in a new terminal window."
