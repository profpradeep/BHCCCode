#!/usr/bin/env bash
script_dir="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
exec /usr/bin/env bash "$script_dir/scripts/bootstrap.sh"
