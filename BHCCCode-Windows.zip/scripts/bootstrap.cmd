@echo off
setlocal

:: Double-click entry point for Windows students. This keeps PowerShell open
:: so installation progress and any error message remain visible.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0bootstrap.ps1"
set "exit_code=%ERRORLEVEL%"

if not "%exit_code%"=="0" (
  echo.
  echo Setup did not finish. Review the message above and try again.
) else (
  echo.
  echo Setup finished successfully.
)
pause
exit /b %exit_code%
