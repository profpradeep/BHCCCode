<#
Installs Hatch prerequisites for the current Windows user only, then configures
an isolated Hatch VS Code profile. Double-click bootstrap.cmd from the extracted
release folder, or run this script manually from that folder.
#>
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$RepositoryRoot = Split-Path -Parent $PSScriptRoot
$BrandingPath = Join-Path $RepositoryRoot 'cli\branding.json'
if (-not (Test-Path -LiteralPath $BrandingPath)) { throw 'The extracted installer is missing cli\branding.json.' }
$Branding = Get-Content -LiteralPath $BrandingPath -Raw | ConvertFrom-Json
$ProductName = [string]$Branding.productName
$CommandName = [string]$Branding.commandName
$IconRelativePath = if ($null -eq $Branding.iconPath) { $null } else { [string]$Branding.iconPath }
$HatchHome = if ($env:HATCH_HOME) { $env:HATCH_HOME } else { Join-Path $HOME '.hatch' }
$NodeHome = Join-Path $HatchHome 'runtime\node'
$AppHome = Join-Path $HatchHome 'app'
$UserCodeBin = Join-Path $env:LOCALAPPDATA 'Programs\Microsoft VS Code\bin'
$UserGitBin = Join-Path $env:LOCALAPPDATA 'Programs\Git\cmd'

function Test-Command([string]$Name) {
  return $null -ne (Get-Command $Name -ErrorAction SilentlyContinue)
}

function Add-UserPath([string]$Path) {
  if (-not (Test-Path -LiteralPath $Path)) { return }
  if ($env:Path -notlike "*$Path*") { $env:Path = "$Path;$env:Path" }
  $userPath = [Environment]::GetEnvironmentVariable('Path', 'User')
  if ([string]::IsNullOrEmpty($userPath)) { $userPath = $Path }
  elseif ($userPath -notlike "*$Path*") { $userPath = "$Path;$userPath" }
  [Environment]::SetEnvironmentVariable('Path', $userPath, 'User')
}

function Install-WingetPackage([string]$Id, [string]$Name, [string[]]$ExtraArgs = @(), [switch]$InstallerControlsScope) {
  Write-Host "Installing $Name for the current user..."
  $arguments = @('install', '--id', $Id, '--exact', '--source', 'winget', '--accept-package-agreements', '--accept-source-agreements')
  if (-not $InstallerControlsScope) { $arguments += @('--scope', 'user') }
  $arguments += $ExtraArgs
  & winget @arguments
  if ($LASTEXITCODE -ne 0) { throw "Could not install $Name for the current user with winget." }
}

function Install-UserNode {
  $nodeExe = Join-Path $NodeHome 'node.exe'
  if (Test-Path -LiteralPath $nodeExe) { Add-UserPath $NodeHome; return }

  $existingNode = Get-Command node.exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($existingNode) {
    $existingHome = Split-Path -Parent $existingNode.Source
    $existingNpm = Join-Path $existingHome 'npm.cmd'
    try {
      $version = & $existingNode.Source --version 2>$null
      if ($LASTEXITCODE -eq 0 -and $version -match '^v24\.\d+\.\d+$' -and (Test-Path -LiteralPath $existingNpm)) {
        & $existingNpm --version 2>$null | Out-Null
        if ($LASTEXITCODE -eq 0) {
          $script:NodeHome = $existingHome
          $env:Path = "$existingHome;$env:Path"
          Write-Host "Using existing Node.js $version at $existingHome"
          return
        }
      }
    } catch { Write-Verbose 'Existing Node.js/npm could not be used; downloading a private runtime.' }
  }

  Write-Host 'Installing Node.js LTS for the current user...'
  $architecture = if ([Environment]::Is64BitOperatingSystem) { if ([Runtime.InteropServices.RuntimeInformation]::ProcessArchitecture -eq 'Arm64') { 'arm64' } else { 'x64' } } else { 'x86' }
  # Node 24 is the current long-term-support release. Its manifest avoids the
  # inconsistent JSON-array handling of Windows PowerShell 5.1.
  $manifestUrl = 'https://nodejs.org/dist/latest-v24.x/SHASUMS256.txt'
  $manifest = (Invoke-WebRequest -Uri $manifestUrl -UseBasicParsing -UserAgent 'Hatch-Code Bootstrap').Content
  $archivePattern = "(?m)^([a-fA-F0-9]{64})\s+(node-(v\d+\.\d+\.\d+)-win-$architecture\.zip)\s*$"
  $archiveMatch = [regex]::Match($manifest, $archivePattern)
  if (-not $archiveMatch.Success) { throw "Could not find a Node.js 24 LTS archive for Windows $architecture." }
  $expectedHash = $archiveMatch.Groups[1].Value.ToLowerInvariant()
  $archiveFileName = $archiveMatch.Groups[2].Value
  $version = $archiveMatch.Groups[3].Value
  $downloadUrl = "https://nodejs.org/dist/$version/$archiveFileName"

  $temporaryRoot = Join-Path ([IO.Path]::GetTempPath()) "hatch-node-$version-$architecture"
  $archive = Join-Path $temporaryRoot 'node.zip'
  try {
    New-Item -ItemType Directory -Path $temporaryRoot -Force | Out-Null
    Write-Host "Downloading $downloadUrl"
    Invoke-WebRequest -Uri $downloadUrl -OutFile $archive -UseBasicParsing -UserAgent 'Hatch-Code Bootstrap'
    $actualHash = (Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actualHash -ne $expectedHash) { throw 'The downloaded Node.js archive did not match its published checksum.' }
    Expand-Archive -LiteralPath $archive -DestinationPath $temporaryRoot -Force
    $extracted = Get-ChildItem -LiteralPath $temporaryRoot -Directory | Where-Object { $_.Name -like 'node-v*-win-*' } | Select-Object -First 1
    if ($null -eq $extracted) { throw 'The Node.js archive did not contain the expected runtime directory.' }
    New-Item -ItemType Directory -Path (Split-Path -Parent $NodeHome) -Force | Out-Null
    Move-Item -LiteralPath $extracted.FullName -Destination $NodeHome -Force
  } finally {
    Remove-Item -LiteralPath $temporaryRoot -Recurse -Force -ErrorAction SilentlyContinue
  }
  Add-UserPath $NodeHome
}

function Install-HatchApplication {
  $sourceCli = Join-Path $RepositoryRoot 'cli'
  $sourceProfile = Join-Path $RepositoryRoot 'vscode-profile'
  if (-not (Test-Path -LiteralPath $sourceCli) -or -not (Test-Path -LiteralPath $sourceProfile)) {
    throw 'The extracted installer is incomplete: cli and vscode-profile are required.'
  }

  $temporaryApp = Join-Path $HatchHome 'app-installing'
  Remove-Item -LiteralPath $temporaryApp -Recurse -Force -ErrorAction SilentlyContinue
  New-Item -ItemType Directory -Path $temporaryApp -Force | Out-Null
  Copy-Item -LiteralPath $sourceCli -Destination (Join-Path $temporaryApp 'cli') -Recurse
  Copy-Item -LiteralPath $sourceProfile -Destination (Join-Path $temporaryApp 'vscode-profile') -Recurse
  Remove-Item -LiteralPath $AppHome -Recurse -Force -ErrorAction SilentlyContinue
  Move-Item -LiteralPath $temporaryApp -Destination $AppHome
}

function New-HatchDesktopShortcut {
  $desktop = [Environment]::GetFolderPath([Environment+SpecialFolder]::Desktop)
  $npmPrefix = (& npm prefix --global).Trim()
  $launcher = Join-Path $npmPrefix "$CommandName.cmd"
  if (-not (Test-Path -LiteralPath $launcher)) { throw "Could not find the $ProductName launcher at $launcher." }

  New-Item -ItemType Directory -Path $HatchHome -Force | Out-Null
  $hiddenLauncher = Join-Path $HatchHome 'launch-hatch-code.vbs'
  $launchLog = Join-Path $HatchHome 'launch-hatch-code.log'
  @"
Set shell = CreateObject("WScript.Shell")
Set processEnvironment = shell.Environment("PROCESS")
processEnvironment("PATH") = "$NodeHome;$UserCodeBin;" & processEnvironment("PATH")

launcher = "$launcher"
logFile = "$launchLog"
command = shell.ExpandEnvironmentStrings("%ComSpec%") & " /d /c call """ & launcher & """ > """ & logFile & """ 2>&1"

On Error Resume Next
exitCode = shell.Run(command, 0, True)
errorNumber = Err.Number
errorDescription = Err.Description
Err.Clear

If errorNumber <> 0 Or exitCode <> 0 Then
  details = ""
  Set fileSystem = CreateObject("Scripting.FileSystemObject")
  If fileSystem.FileExists(logFile) Then
    Set logStream = fileSystem.OpenTextFile(logFile, 1)
    details = Trim(logStream.ReadAll)
    logStream.Close
  End If
  If Len(details) > 3000 Then details = "..." & Right(details, 3000)
  If errorDescription <> "" Then details = errorDescription & vbCrLf & details
  If details = "" Then details = "No diagnostic output was produced."
  shell.Popup "$ProductName could not start." & vbCrLf & vbCrLf & details & vbCrLf & vbCrLf & "Details were saved to:" & vbCrLf & logFile, 0, "$ProductName launch error", 16
End If
"@ | Set-Content -LiteralPath $hiddenLauncher -Encoding Unicode -NoNewline

  $shell = New-Object -ComObject WScript.Shell
  $shortcut = $shell.CreateShortcut((Join-Path $desktop "$ProductName.lnk"))
  $shortcut.TargetPath = Join-Path $env:SystemRoot 'System32\wscript.exe'
  $shortcut.Arguments = '"' + $hiddenLauncher + '"'
  $shortcut.WorkingDirectory = $HatchHome
  $shortcut.Description = "Open the isolated $ProductName development environment"
  $customIcon = if ($IconRelativePath) { Join-Path (Join-Path $AppHome 'cli') $IconRelativePath } else { $null }
  $codeIcon = Join-Path $env:LOCALAPPDATA 'Programs\Microsoft VS Code\Code.exe'
  if ($customIcon -and (Test-Path -LiteralPath $customIcon)) { $shortcut.IconLocation = "$customIcon,0" }
  elseif (Test-Path -LiteralPath $codeIcon) { $shortcut.IconLocation = "$codeIcon,0" }
  $shortcut.Save()
}

if (-not (Test-Command 'winget')) {
  throw 'Windows Package Manager (winget) is required. Update App Installer from the Microsoft Store, then run this script again.'
}

Install-UserNode
if (-not (Test-Command 'git')) {
  Install-WingetPackage 'Git.Git' 'Git'
}
Add-UserPath $UserGitBin
if (-not (Test-Path -LiteralPath (Join-Path $UserCodeBin 'code.cmd'))) {
  Install-WingetPackage 'Microsoft.VisualStudioCode' 'Visual Studio Code'
}
Add-UserPath $UserCodeBin

Install-HatchApplication
$env:npm_config_prefix = Join-Path $HatchHome 'npm'
Push-Location $AppHome
try {
  npm install --global ./cli
  $npmPrefix = (& npm prefix --global).Trim()
  Add-UserPath $npmPrefix
  $hatchCommand = Join-Path $npmPrefix "$CommandName.cmd"
  if (-not (Test-Path -LiteralPath $hatchCommand)) { throw "$ProductName was installed but its launcher was not found at $hatchCommand." }
  & $hatchCommand configure-languages
  if ($LASTEXITCODE -ne 0) { throw "$ProductName language setup failed with exit code $LASTEXITCODE." }
  New-HatchDesktopShortcut
} finally {
  Pop-Location
}

Write-Host "$ProductName is configured for the current Windows user. Open any folder from the desktop shortcut or $CommandName command."
